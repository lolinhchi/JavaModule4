package model;

public class MemberRepository {
	public Member logOn(String usr) {
		return null;
	}
}
